package main
import (
    log "github.com/Sirupsen/logrus"
    "github.com/urfave/cli"//这个包提供了命令行工具
    "os"
    "fmt"
    "os/exec"
    "syscall"
    )
const usage = ` just for fun.`
func main() {
    app := cli.NewApp()
    app.Name = "mydocker"
    app.Usage = usage
    //定义两个命令init、run
    app.Commands = []cli.Command{
        initCommand,
        runCommand,
    }
    //`app.Before` 内初始化了一下`logrus`的日志配置。
    app.Before = func(context *cli.Context) error {
        // Log as JSON instead of the default ASCII formatter.
        log.SetFormatter(&log.JSONFormatter{})
        log.SetOutput(os.Stdout)
        return nil
    }
    //运行出错时 记录日志
    if err := app.Run(os.Args); err != nil {
        log.Fatal(err)
    }
}
var runCommand = cli.Command{
    Name:  "run",
    Usage: `Create a container with namespace and cgroups limit
                mydocker run -ti [command]`,
    Flags: []cli.Flag{
        cli.BoolFlag{
            Name:        "ti",
            Usage:       "enable tty",
        },
    },
    //这里是run命令执行的真正函数
    Action:func(context *cli.Context) error {
        if len(context.Args()) < 1 {//判断是否包含参数
            return fmt.Errorf("Missing container command")
        }
        cmd := context.Args().Get(0)//获取参数
        tty := context.Bool("ti")
        Run(tty, cmd)//调用Run方法去准备启动容器
        return nil
    },
}
//此方法禁止外部调用

var initCommand = cli.Command{
    Name:   "init",
    Usage:  "Init container process run user's process in container. Do not call it outside",
    Action:func(context *cli.Context) error {
        log.Infof("init come on")
        cmd := context.Args().Get(0)//获取传递过来的参数
        
        err := RunContainerInitProcess(cmd, nil)//执行容器初始化操作
        return err
    },
}

func NewParentProcess(tty bool, command string) *exec.Cmd {
    args := []string{"init", command}
    //init 是传给本进程的第一个参数  这里用init去初始化进程的环境和资源
    cmd := exec.Command("/proc/self/exe", args...)
    //这里/proc/self是指当前运行进程自己的环境,也就是exec调用了exec 
    cmd.SysProcAttr = &syscall.SysProcAttr{
        Cloneflags: syscall.CLONE_NEWUTS | syscall.CLONE_NEWPID | syscall.CLONE_NEWNS |
        syscall.CLONE_NEWNET | syscall.CLONE_NEWIPC,
    }//这里fork一个新进程，使用了namespace，也是ver1的主要部分
    if tty {//stdio
        cmd.Stdin = os.Stdin
        cmd.Stdout = os.Stdout
        cmd.Stderr = os.Stderr
    }
    return cmd//返回进程
}
//返回cmd之后的调用
func Run(tty bool, command string) {
    parent := NewParentProcess(tty, command)//调用NewParentProcess去初始化相关命令所要的容器环境
    if err := parent.Start(); err != nil {
        log.Error(err)
    }//start方法真正调用了前面创建好的command进程，也就是之前ver1的功能并调用init方法
    parent.Wait()
    os.Exit(-1)
}
//内部函数，代码到这里的时候容器进程已经创建了

func RunContainerInitProcess(command string, args []string) error {
    
    defaultMountFlags := syscall.MS_NOEXEC | syscall.MS_NOSUID | syscall.MS_NODEV
    syscall.Mount("proc", "/proc", "proc", uintptr(defaultMountFlags), "")
    //这里用Mount的作用是挂载proc文件系统，可以使用ps等系统命令
    argv := []string{command}
    if err := syscall.Exec(command, argv, os.Environ()); err != nil {
        err.Error()
    }
    /*这里是为了把init进程改为用户进程（for instance /bin/sh),但是此时PID=1的为init
    execve方法可以调用 kernel的`int execve(const char *filename,char *const argv[],char *envp)
    执行当前filename对应的程序 覆盖当前进程，替换掉init进程。这样就实现了进入容器内的第一个程序是我们制定的进程。
    init 真实 工 具 人*/
    return nil
}
