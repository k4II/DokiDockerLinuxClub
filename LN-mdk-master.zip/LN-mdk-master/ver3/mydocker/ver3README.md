依赖: 

https://github.com/Sirupsen/logrus.git

https://github.com/urfave/cli.git
(还需要一个 golang.org/x/sys)

实现功能:实现了一个简单的run命令
具体操作如图所示:
![hhhhhhh.png](https://i.loli.net/2019/06/16/5d052edfc1c5593887.png)
