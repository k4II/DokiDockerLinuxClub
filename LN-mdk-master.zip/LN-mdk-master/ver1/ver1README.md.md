### 0. go and run

这个程序的核心就是启用Namespace。

如何启用相应Namespace呢？

通过系统调用clone()来创建一个具有独立Namespace的进程是最常见的做法，它可以通过flags参数传入相应标志位来控制进程的各种状态。

```cpp
pid = clone(fun,stack,flags,clone_arg);
(flags:CLONE_NEWPID  | CLONE_NEWNS |
    CLONE_NEWUSER | CLONE_NEWNUT |
    CLONE_NEWIPC  | CLONE_NEWUTS |
    ...)
```

详细信息去找那个男人。


### 1.程序测试

运行程序后，进入交互式环境，使用`pstree -pl`查看一下系统中进程之间的关系，然后用`echo $$`输出一下当时的PID。改hostname；比如 `hostname -b ycy`;再检查hostname发现改名成功。新开一个终端，输入hostname ，发现结果没变。而且只要退出进程再一次运行程序后查看hostname,也发现之前更名没有效果。查看uts也可以发现uts不一样，所以uts被隔离了。同样的，我们使用 `ipcs -q`查看宿主机的ipc Message Queues ；再用`ipcmk -Q`创建一个message queue，发现可以看到一个queue了。运行程序后，我们再使用 `ipcs -q`查看容器（虽然现在不能称作一个合格的容器)的ipc Message Queues ；发现看不到我们在宿主机创建的queue，说明IPC被隔离了。


![1.png](https://i.loli.net/2019/06/14/5d03235d6646a31388.png)

![2.png](https://i.loli.net/2019/06/14/5d032250d922a15116.png)

![3..png](https://i.loli.net/2019/06/14/5d0322e3d208977948.png)

同样的一个进程在不同的 PID Namespace 里面可以拥有不同的 PID。用进程树 `pstree -pl`我们查看这个容器（其实就是一个进程）的真实PID，也就是看这个函数运行的PID。运行程序，使用`echo $$`我们打印了当前namespace的pid，发现是1，也就是说这个实际的PID 被映射到 namesapce 里面的 PID 为1。  

chroot()有点危险了，而Namespace里的Mount Namespace 能做到一样的事情。在调用NEWNS 后，运行代码，查看 /proc的文件内容，发现现在还是宿主机的内容，然后进行挂载 `mount -t proc proc /proc` 这时候`ls /proc`发现对比宿主机，可以看到瞬间少了很多文件。`ps -ef`也能看到区别，UID 显示为root 并且只有两个进程。也就是说，在当前namesapce里面，我们的sh 进程是PID 为1 的进程。（后来用了cgroup PID就不是1了）这里就说明，我们当前的Mount namesapce 里面的mount 和外部空间是隔离的，mount 操作并没有影响到外部。接下来就是User NameSpace的使用了。User namespace 主要是隔离用户的用户组ID。也就是说，一个进程的User ID 和Group ID 在User namespace 内外可以是不同的。 比较常用的是，在宿主机上以一个非root用户运行创建一个User namespace，然后在User namespace里面却映射成root 用户。这个进程在User namespace里面有root权限，但是在User namespace外面却没有root的权限。并且，经过我的测试，user namespace 里也可以创建没有root权限的用户。

![xd.png](https://i.loli.net/2019/06/14/5d0324642d63779226.png)

没有root权限:

![7777.png](https://i.loli.net/2019/06/14/5d0327588fd1535395.png)



最后是网络隔离，先在宿主机用`ifconfig`查看当前的网络设备，然后运行容器，用`ifconfig`查看后，发现啥也没有，应该就是隔离成功了。但是，这里是可以自己再独立出一个网络环境出来的。

另外，这里用cgroup做了一个容器资源限制，但是`stress`没跑成，我就把相关的命令删掉了，也不知道成功了没有。。。

### 2.体会

我是用的go完成的，C对于我来说有点难，虽然恶补了一下linux C编程基础，但是好像还是"go真香"。（另外在Linux下面用C才用得爽啊。。。可是学校教C都是在windows下的，甚至还用的VC 6++，然后让你做数学题，我倒 ）我看过C的教程，（比如酷壳里面陈皓写的那篇以及他参考的那些文章，还有一个候海云dalao总结得也很好）和用C完成作业的盆友交流后发现效果是很多是一样的，连出现的问题都是一样的，比如sudo用多了到后面会出错（sudo: no tty present and no askpass program specifie )，得用root或者重启。但是在这个ver1中，完成的事情没那么多，比如网络隔离那块和挂rootf这里。
完成了上面那些微小的工作后，对这两篇文章有了更深的了解。

[理解Docker：Docker 使用 Linux namespace 隔离容器的运行环境](https://www.cnblogs.com/sammyliu/p/5878973.html)

[理解Docker：Docker 容器使用 cgroups 限制资源使用](https://www.cnblogs.com/sammyliu/p/5886833.html)

谁能想到一个还在挣扎于dockerfile的人现在在研究容器原理呢，虽然这样确实很酷。

### 3.linux的stdio概念

也就是标准输入输出概念。

linux系统在调用某个程序时，通常会有三个标准I/O通道对其开放。使用**stdin**作为数据输入（可能来自一个文件或者通过管道连接的其他程序)，使用**stdout**作为数据输出（可以输出在任何地方），使用**stderr**处理外带信息，这是不应该出现在stdout数据流中的。

这个做法不同于其他的操作系统，其他操作系统很多是硬性实现I/O接口的。

这里就用了这个设计思想。









