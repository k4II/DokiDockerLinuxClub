#### 利用py进行对docker的隔离实现的复现



即通过调用命令去看看docker实现的功能，看到和 docker（Ubuntu bash) 一样的视图

![2.png](https://i.loli.net/2019/06/14/5d0383a12ee6630838.png)


![捕获.png](https://i.loli.net/2019/06/14/5d0382b526b7021923.png)
